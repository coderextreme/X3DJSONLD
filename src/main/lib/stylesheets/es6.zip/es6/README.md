#  ECMAScript 6 library for X3D

Python programmers welcome!

packageGenerator.py generates ECMAscript package.

Run it like:
```
python packageGenerator.py
```

That python processs creates x3d.mjs and x3d.mjs is the ECMAScript 6 module

No current tests

Run it like:
```
node app.mjs

```
Currently XML generation is not complete.  Contributions welcome.

Do not modify x3d.js
