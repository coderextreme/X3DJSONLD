These XSLT Stylesheets convert XML-based .x3d scenes into alternate formats
and encodings.  They are maintained under an open-source license and online at
   http://www.web3d.org/x3d/stylesheets

with version control maintained at
   http://svn.code.sf.net/p/x3d/code/www.web3d.org/x3d/stylesheets

X3D stylesheet descriptions are included in the X3D Resources, online at
   http://www.web3d.org/x3d/content/examples/X3dResources.html#Stylesheets

Point of contact:   Don Brutzman  brutzman@nps.edu
