Icons by https://feathericons.com/

License: MIT ( https://github.com/feathericons/feather/blob/main/LICENSE )

Thank you!