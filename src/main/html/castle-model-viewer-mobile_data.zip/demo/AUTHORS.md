# Authors of 3D graphics used in this project

Thank you for the amazing 3D stuff we could use to showcase our project!

- cat:
    - From https://sketchfab.com/3d-models/cat-murdered-soul-suspect-836312def1b84e588866500a2bf79f0f
    - License: CC Attribution
    - Author: mark2580 ( https://sketchfab.com/mark2580 )

- steampunk underwater explorer:
    - From https://sketchfab.com/3d-models/steampunk-underwater-explorer-127471a23e0f4790914b13b9052c4912
    - License: CC Attribution
    - Author: Andrius Beconis ( https://sketchfab.com/abeconis )

- dungeon:
    - From https://sketchfab.com/3d-models/dungeon-2ee94272dbf5456792eb9909c4638d1d
    - License: CC Attribution
    - Author: Federico Terzi ( https://sketchfab.com/Federico.Terzi )

- The rest of graphics (mostly hand-crafted X3D files) was done by _Michalis Kamburelis_.
