Animated dragon in Spine JSON format.

You can open it e.g. in Castle Game Engine ( https://castle-engine.io/ ) that supports Spine. You can quickly test it by opening in our model viewer: https://castle-engine.io/castle-model-viewer .

By Paweł Wojciechowicz from https://cat-astrophe-games.com/ .
Licensed on the GNU GPL >= 2 terms.
